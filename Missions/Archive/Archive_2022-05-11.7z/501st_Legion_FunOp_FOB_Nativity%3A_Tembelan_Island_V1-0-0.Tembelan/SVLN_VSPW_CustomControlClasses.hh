//Exported via Arma Dialog Creator (https://github.com/kayler-renslow/arma-dialog-creator)
#ifndef HG_SVLN_VSPW_CustomControlClasseshh
#define HG_SVLN_VSPW_CustomControlClasseshh 1
//Create a header guard to prevent duplicate include.

#endif
